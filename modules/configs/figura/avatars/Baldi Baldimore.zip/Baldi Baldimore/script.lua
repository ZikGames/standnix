vanilla_model.PLAYER:setVisible(false)
vanilla_model.ARMOR:setVisible(false)
vanilla_model.ELYTRA:setVisible(false)
models.model:setScale(1.3)
nameplate.ENTITY:setPivot(0,2.6,0)

function events.item_render(item)
    if item.id:find("sword") then
        return models.ruler.ItemRuler
    end
end


function events.render(delta, context)
  if context == 'FIRST_PERSON' then
    models.model.root.RightArm:setPos(2, -2, 0)
  else
    models.model.root.RightArm:setPos() -- reset
  end
end




