local cosumesLib = require("scripts.libs.costumes")

vanilla_model.ALL:setVisible(false)

local mainPage = action_wheel:newPage("Main")
cosumesLib:newCategory("Skins", textures["assets.textures.icons.costume"])
    :addCostume("Steve", models.assets.models.costumes.steve, textures["assets.textures.costumes.steve_icon"])
    :addCostume("Alex", models.assets.models.costumes.alex, textures["assets.textures.costumes.alex_icon"])

local costumesPage = cosumesLib:getWheel("Costumes")
costumesPage:newAction()
    :title("Back")
    :texture(textures["assets.textures.icons.left-down-slew"])
    :onLeftClick(function (x)
        action_wheel:setPage(mainPage)
    end)

mainPage:newAction()
    :title("Costumes")
    :item("minecraft:diamond")
    :onLeftClick(function (x)
        action_wheel:setPage(costumesPage)
    end)
action_wheel:setPage(mainPage)