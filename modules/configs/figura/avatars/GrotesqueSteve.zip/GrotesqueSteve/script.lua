vanilla_model.PLAYER:setVisible(false)
vanilla_model.ARMOR:setVisible(false)
vanilla_model.CAPE:setVisible(false)
vanilla_model.ELYTRA:setVisible(false)

renderer:setOffsetCameraPivot(0,-0.26,0)


function events.render()
    if player:isCrouching() then models.grotesqueSteve.root:setPos(0,2.85,0)
    else models.grotesqueSteve.root:setPos(0,0,0) end


end