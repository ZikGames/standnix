---comment
---@param self CostumeCategory
---@param name string
---@param model ModelPart
---@param texture Texture
---@return CostumeInfo
local newCostume = function(self, name, model, texture)
    ---@class CostumeInfo
    local instance = {
        name = name,
        type = type,
        model = model,
        texture = texture,
    }

    table.insert(self.cosutmes, instance)
    model:setVisible(false)

    return instance
end

---comment
---@param self CostumeCategory
---@param name string
---@param texture Texture
---@param model ModelPart
---@return CostumeCategory
local addCostume = function(self, name, model, texture)
    newCostume(self, name, model, texture)
    return self
end

---comment
---@param self CostumesLib
---@param name string
---@param texture Texture
---@return CostumeCategory
local newCategory = function(self, name, texture)
    ---@class CostumeCategory
    local instance = {
        name = name,
        texture = texture,
        cosutmes = {},

        newCostume = newCostume,
        addCostume = addCostume
    }

    ---@diagnostic disable-next-line: undefined-field
    table.insert(self.categories, instance)

    return instance
end

---comment
---@param model ModelPart
---@param path string
---@return ModelPart | nil
local function getModel(model, path)
    local parts = {}
    for part in string.gmatch(path, "([^%.]+)") do
        table.insert(parts, part)
    end
    local current = model
    for _, name in ipairs(parts) do
        local found = nil
        for _, child in ipairs(current:getChildren()) do
            if child:getName() == name then
                found = child
                break
            end
        end
        if not found then
            return nil
        end
        current = found
    end

    return current
end

---comment
---@param model ModelPart
---@return string
local function getModelPath(model)
    local names = {}
    local current = model

    while current do
        table.insert(names, 1, current:getName())
        current = current:getParent()
    end

    table.remove(names, 1)
    local output = table.concat(names, ".")
    
    return output
end


---comment
---@param model string
---@param state boolean
pings.toggleModel = function(model, state)
    local val = getModel(models, model)
    if (val == nil or val == models) then
        return
    end
    val:setVisible(state)
end

---@class CostumesLib
return {
    categories = {},

    newCategory = newCategory,

    getWheel = function(self, title)
        local instance = action_wheel:newPage(title)
        
        for _, value in ipairs(self.categories) do
            ---@type CostumeCategory
            local category = value
            local categoryPage = action_wheel:newPage(category.name)

            for _, value_ in ipairs(category.cosutmes) do
                ---@type CostumeInfo
                local costume = value_
                costume._action = function (toggle, me)
                        if (toggle == true) then
                            for index, item in ipairs(categoryPage:getActions()) do
                                if (item:isToggled() == true and item ~= me) then
                                    item:setToggled(false)
                                    category.cosutmes[index]._action(false, item)
                                end
                            end
                        end
                        pings.toggleModel(getModelPath(costume.model), toggle)
                    end
                categoryPage:newAction()
                    :title(costume.name)
                    :texture(costume.texture)
                    :onToggle(costume._action)
            end

            categoryPage:newAction()
                :title("Back")
                :texture(textures["assets.textures.icons.left-down-slew"])
                :onLeftClick(function (x)
                    action_wheel:setPage(instance)
                end)

            instance:newAction()
                :title(category.name)
                :texture(category.texture)
                :onLeftClick(function (x)
                    action_wheel:setPage(categoryPage)
                end)
        end

        return instance
    end
}