--[[
      _       _        _                   _    ____ ___ 
     | |_   _| | _____| |__   _____  __   / \  |  _ \_ _|
  _  | | | | | |/ / _ \ '_ \ / _ \ \/ /  / _ \ | |_) | | 
 | |_| | |_| |   <  __/ |_) | (_) >  <  / ___ \|  __/| | 
  \___/ \__,_|_|\_\___|_.__/ \___/_/\_\/_/   \_\_|  |___|

        ____              _           _       ____                
       | __ ) _   _      | |_   _ ___| |_    / ___|   _ _ __ __ _ 
       |  _ \| | | |  _  | | | | / __| __|  | |  | | | | '__/ _` |
       | |_) | |_| | | |_| | |_| \__ \ |_   | |__| |_| | | | (_| |
       |____/ \__, |  \___/ \__,_|___/\__|___\____\__, |_|  \__,_|
              |___/                     |_____|   |___/           
--]]

-- Version: 1.2.0

--- @class JukeboxAPI.Timer
--- @field count integer
--- @field current_note_set? JukeboxAPI.Sound.note_set
--- @field last_position? Vector3
---
--- @field restart? fun(self: JukeboxAPI.Timer, note_set?: JukeboxAPI.Sound.note_set)

--- @class JukeboxAPI.Sound
--- @field item_id Minecraft.itemID
--- @field name string

--- @class JukeboxAPI.Sound.normal : JukeboxAPI.Sound
--- @field sound_id Minecraft.soundID|string

--- @class JukeboxAPI.Sound.note_set : JukeboxAPI.Sound
--- @field notes JukeboxAPI.Sound.note_set.note[]

--- @alias JukeboxAPI.Sound.note_set.note JukeboxAPI.Sound.note_set.entry[]

--- @class JukeboxAPI.Sound.note_set.entry
--- @field note JukeboxAPI.Sound.note_set.valid_notes
--- @field volume? number
--- @field pitch? number

--- @alias JukeboxAPI.Sound.note_set.valid_notes
---| "minecraft:block.note_block.banjo"                           # Block: Note Block Banjo
---| "minecraft:block.note_block.basedrum"                        # Block: Note Block Basedrum
---| "minecraft:block.note_block.bass"                            # Block: Note Block Bass
---| "minecraft:block.note_block.bell"                            # Block: Note Block Bell
---| "minecraft:block.note_block.bit"                             # Block: Note Block Bit
---| "minecraft:block.note_block.chime"                           # Block: Note Block Chime
---| "minecraft:block.note_block.cow_bell"                        # Block: Note Block Cow Bell
---| "minecraft:block.note_block.didgeridoo"                      # Block: Note Block Didgeridoo
---| "minecraft:block.note_block.flute"                           # Block: Note Block Flute
---| "minecraft:block.note_block.guitar"                          # Block: Note Block Guitar
---| "minecraft:block.note_block.harp"                            # Block: Note Block Harp
---| "minecraft:block.note_block.hat"                             # Block: Note Block Hat
---| "minecraft:block.note_block.imitate.creeper"                 # Block: Note Block Imitate Creeper
---| "minecraft:block.note_block.imitate.ender_dragon"            # Block: Note Block Imitate Ender Dragon
---| "minecraft:block.note_block.imitate.piglin"                  # Block: Note Block Imitate Piglin
---| "minecraft:block.note_block.imitate.skeleton"                # Block: Note Block Imitate Skeleton
---| "minecraft:block.note_block.imitate.wither_skeleton"         # Block: Note Block Imitate Wither Skeleton
---| "minecraft:block.note_block.imitate.zombie"                  # Block: Note Block Imitate Zombie
---| "minecraft:block.note_block.iron_xylophone"                  # Block: Note Block Iron Xylophone
---| "minecraft:block.note_block.pling"                           # Block: Note Block Pling
---| "minecraft:block.note_block.snare"                           # Block: Note Block Snare
---| "minecraft:block.note_block.xylophone"                       # Block: Note Block Xylophone

--- @alias JukeboxAPI.Sound.any JukeboxAPI.Sound.normal | JukeboxAPI.Sound.note_set

--- @class JukeboxAPI.Config
--- @field target_page? Page Target Action Wheel Page to fill with Registered Sounds
--- @field apply_zebra_stripping_to_actions boolean Should every second Action in the Target Action Wheel Page use Zebra Striping
--- @field back_action boolean Should add an action to go back to a category specified in `back_action_page`
--- @field back_action_page? Page Page to go back to if a back action is made due to `back_action`
--- @field back_action_name string Name of the action that takes you back due to `back_action`
--- @field setTargetPage? fun(self: JukeboxAPI.Config, page: Page): JukeboxAPI.Config
--- @field setActionColor? fun(self: JukeboxAPI.Config, color?: Vector3|string): JukeboxAPI.Config
--- @field setActionZebraStripping? fun(self: JukeboxAPI.Config, boolean?: boolean): JukeboxAPI.Config
--- @field setBackAction? fun(self: JukeboxAPI.Config, boolean?: boolean, page?: Page, name?: string): JukeboxAPI.Config

--- @class JukeboxAPI.Colors
--- @field primary? Vector3
--- @field hover? Vector3
--- @field back? Vector3
--- @field positive? Vector3
--- @field negative? Vector3
---
--- @field applyZebraStripping fun(self: JukeboxAPI.Colors, index: integer, color?: Vector3): color: Vector3
--- @field setColors fun(self: JukeboxAPI.Colors, color: Vector3)

--- @class JukeboxAPI.Log
--- @field colors table<JukeboxAPI.Log.type, string>

--- @alias JukeboxAPI.Log.type 'info'|'warning'|'error' 
--- @alias JukeboxAPI.Log.func fun(log_type: JukeboxAPI.Log.type, source: string, message: string, ...?: any)

--- @class JukeboxAPI
--- @field timer JukeboxAPI.Timer
--- @field sounds JukeboxAPI.Sound.any[]
--- @field config JukeboxAPI.Config
--- @field colors JukeboxAPI.Colors
--- @field log JukeboxAPI.Log | JukeboxAPI.Log.func
--- @field events JukeboxAPI.Events
local jukeboxAPI = {}

jukeboxAPI.timer = {
    count = 0,
}
--- List of all registered Music Discs
jukeboxAPI.sounds = {}
--- List of configuration options
jukeboxAPI.config = {
    apply_zebra_stripping_to_actions = true,
    back_action = false,
    back_action_name = 'Go Back',
}
--- List of colors used by JukeboxAPI
jukeboxAPI.colors = {
    --- Return a `color` with slight variation depend on `index`
    --- Does nothing if config `apply_zebra_stripping_to_actions` is false an returns unmodified `color`
    applyZebraStripping = function (self, index, color)
        color = color or self.primary

        if jukeboxAPI.config.apply_zebra_stripping_to_actions then
            return index % 2 == 1 and (color * 1.5):applyFunc(function (v) return v > 1 and 1 or v end) or color
        else
            return color
        end
    end,
    setColors = function (self, color)
        self.primary = color * 0.85
        self.hover = self.primary * 0.75
        self.back = vec(1.0, 0, 0)
        self.positive = vec(0, 0.75, 0)
        self.negative = vec(0.75, 0.25, 0.25)
    end
}
--- Function and list of colors to use for Logging used for JukeboxAPI
jukeboxAPI.log = {
    colors = {
        info = '§7',
        warning = '§e',
        error = '§c'
    }
}

setmetatable(jukeboxAPI.log --[[@as JukeboxAPI.Log]], {
    --- Log tool used in `JukeboxAPI`
    --- @param self JukeboxAPI.Log
    --- @param log_type JukeboxAPI.Log.type
    --- @param source string 
    --- @param message string
    --- @param ...? any Message formatting arguments
    __call = function (self, log_type, source, message, ...)
        local args = {}
        for _, value in pairs({...}) do
            table.insert(args, tostring(value))
        end
        
        local color = self.colors[log_type or 'info']
        log(string.format('%s|-- JukeboxAPI:%s --|', color, source))
        log(string.format(color .. message, table.unpack(args)))
    end
})

--- @class JukeboxAPI.Events
--- @field ON_ACTION_STOP_ALL_SOUNDS JukeboxAPI.Events.StopAllSoundsAction | JukeboxAPI.Events.StopAllSoundsAction.trigger
--- @field ON_ACTION_PLAY_OR_STOP_SOUND JukeboxAPI.Events.PlayOrStopSoundAction | JukeboxAPI.Events.PlayOrStopSoundAction.trigger
--- @field ON_TIMER_CHANGE JukeboxAPI.Events.TimerChange | JukeboxAPI.Events.TimerChange.trigger

--- @alias JukeboxAPI.Events.flags 'skip'

--- @alias JukeboxAPI.Events.StopAllSoundsAction.register
--- | fun(self: table, func: JukeboxAPI.Events.StopAllSoundsAction.func): table<'skip', boolean>?
--- @alias JukeboxAPI.Events.StopAllSoundsAction.trigger
--- | JukeboxAPI.Events.StopAllSoundsAction.func
--- @alias JukeboxAPI.Events.StopAllSoundsAction.func
--- | fun(action: Action, index: integer): table<'skip', boolean>[]?

--- @class JukeboxAPI.Events.StopAllSoundsAction
--- @field register JukeboxAPI.Events.StopAllSoundsAction.register
--- @field events JukeboxAPI.Events.StopAllSoundsAction.func[]

--- @alias JukeboxAPI.Events.PlayOrStopSoundAction.register
--- | fun(self: table, func: JukeboxAPI.Events.PlayOrStopSoundAction.func): table<'skip', boolean>?
--- @alias JukeboxAPI.Events.PlayOrStopSoundAction.trigger 
--- | JukeboxAPI.Events.PlayOrStopSoundAction.func
--- @alias JukeboxAPI.Events.PlayOrStopSoundAction.func
--- | fun(action: Action, index: integer, state: boolean, sound: JukeboxAPI.Sound.any): table<'skip', boolean>[]?

--- @class JukeboxAPI.Events.PlayOrStopSoundAction
--- @field register JukeboxAPI.Events.PlayOrStopSoundAction.register
--- @field events JukeboxAPI.Events.PlayOrStopSoundAction.func[]

--- @alias JukeboxAPI.Events.TimerChange.register
--- | fun(self: table, func: JukeboxAPI.Events.TimerChange.func): table<'skip', boolean>?
--- @alias JukeboxAPI.Events.TimerChange.trigger 
--- | JukeboxAPI.Events.TimerChange.func
--- @alias JukeboxAPI.Events.TimerChange.func
--- | fun(timer: JukeboxAPI.Timer, reset: boolean): table<'skip', boolean>[]?

--- @class JukeboxAPI.Events.TimerChange
--- @field register JukeboxAPI.Events.TimerChange.register
--- @field events JukeboxAPI.Events.TimerChange.func[]

---Register a new Event
---@param self { events: fun(...: any)[] }
---@param func fun(...)
---@return boolean success
local function registerEvent(self, func)
    if type(func) ~= 'function' then
        jukeboxAPI.log(
            'error', 'registerEvent()',
            'Unable to register a new Callback Event as provided function is actually "%s"!',
            type(func)
        )
        return false
    end

    table.insert(self.events, func)
    return true
end

---Trigger an Event
---@param self { events: fun(...: any)[] }
---@param ... any Function arguments
---@return table<string, boolean>[]? -- Function return flags
local function triggerEvent(self, ...)
    local returns = {}
    for _, func in ipairs(self.events) do
        local call = func(...)
        if call then
            table.insert(returns, call)
        end
    end
    return #returns > 0 and returns or nil
end

---Check if a Registered Event returns a desired Flag
---@param tbl table<JukeboxAPI.Events.flags, boolean>[]
---@param flag JukeboxAPI.Events.flags
---@return boolean
---@nodiscard
local function containsEventFlag(tbl, flag)
    if not flag or not tbl or type(tbl) ~= 'table' then
        return false
    end

    for _, pair in ipairs(tbl) do
        for key, value in pairs(pair) do
            if key == 'skip' and value then
                return true
            end
        end
    end
    return false
end

--- List of events called by JukeboxAPI
jukeboxAPI.events = {
    ON_ACTION_STOP_ALL_SOUNDS = {
        register = registerEvent,
        events = {}
    },
    ON_ACTION_PLAY_OR_STOP_SOUND = {
        register = registerEvent,
        events = {}
    },
    ON_TIMER_CHANGE = {
        register = registerEvent,
        events = {}
    }
}

setmetatable(jukeboxAPI.events.ON_ACTION_STOP_ALL_SOUNDS --[[@as table]], {
    --- @type JukeboxAPI.Events.StopAllSoundsAction.trigger
    __call = triggerEvent
})
setmetatable(jukeboxAPI.events.ON_ACTION_PLAY_OR_STOP_SOUND --[[@as table]], {
    --- @type JukeboxAPI.Events.PlayOrStopSoundAction.trigger
    __call = triggerEvent
})
setmetatable(jukeboxAPI.events.ON_TIMER_CHANGE --[[@as table]], {
    --- @type JukeboxAPI.Events.TimerChange.trigger
    __call = triggerEvent
})

---Play/Stop a certain sound
---@param sound? Minecraft.soundID
---@param state? boolean
---@param x? number
---@param y? number
---@param z? number
function pings.PlayJukeboxSound(sound, state, x, y, z)
    if sound == nil or state == nil then
        sounds:stopSound()
        return
    end

    if not sounds:isPresent(sound) then
        jukeboxAPI.log(
            'warning', 'pings.PlayJukeboxSound()',
            'Attempted to play an invalid sound "%s"! Skipping...',
            sound
        )
        return
    end

    if state then
        if x and y and z then
            sounds:playSound(sound, vec(x, y, z), 1, 1)
        else
            sounds:playSound(sound, player:getPos(), 1, 1)
        end
    else
        sounds:stopSound(sound)
    end
end

--- Restarts the timer
---@param note_set JukeboxAPI.Sound.note_set?
function jukeboxAPI.timer:restart(note_set)
    if containsEventFlag(jukeboxAPI.events.ON_TIMER_CHANGE(self, true), 'skip') then
        return
    end

    self.count = 0
    self.current_note_set = note_set
end

--- @type table<JukeboxAPI.Sound.note_set.valid_notes, integer>
local soundToNote = {
    ["minecraft:block.note_block.banjo"] = 1,
    ["minecraft:block.note_block.basedrum"] = 2,
    ["minecraft:block.note_block.bass"] = 3,
    ["minecraft:block.note_block.bell"] = 4,
    ["minecraft:block.note_block.bit"] = 5,
    ["minecraft:block.note_block.chime"] = 6,
    ["minecraft:block.note_block.cow_bell"] = 7,
    ["minecraft:block.note_block.didgeridoo"] = 8,
    ["minecraft:block.note_block.flute"] = 9,
    ["minecraft:block.note_block.guitar"] = 10,
    ["minecraft:block.note_block.harp"] = 11,
    ["minecraft:block.note_block.hat"] = 12,
    ["minecraft:block.note_block.imitate.creeper"] = 13,
    ["minecraft:block.note_block.imitate.ender_dragon"] = 14,
    ["minecraft:block.note_block.imitate.piglin"] = 15,
    ["minecraft:block.note_block.imitate.skeleton"] = 16,
    ["minecraft:block.note_block.imitate.wither_skeleton"] = 17,
    ["minecraft:block.note_block.imitate.zombie"] = 18,
    ["minecraft:block.note_block.iron_xylophone"] = 19,
    ["minecraft:block.note_block.pling"] = 20,
    ["minecraft:block.note_block.snare"] = 21,
    ["minecraft:block.note_block.xylophone"] = 22,
}
--- Convert a Note Sound ID to an integer
---@param sound JukeboxAPI.Sound.note_set.valid_notes
---@return integer? note
function jukeboxAPI.soundToNote(sound)
    return soundToNote[sound]
end

--- Convert an integer to a Note Sound ID
---@param note integer
---@return JukeboxAPI.Sound.note_set.valid_notes? sound
function jukeboxAPI.noteToSound(note)
    for key, value in pairs(soundToNote) do
        if value == note then
            return key
        end
    end
end

--- Encodes notes, volume and pitch into a `string` for compact ping sending
---@param tbl JukeboxAPI.Sound.note_set.note
---@return string encoded_notes
function jukeboxAPI:encodeNoteSet(tbl)
    local encoded_notes = ''
    for _, value in ipairs(tbl) do
        local volume = value.volume or 1
        volume = volume % 25 * 10

        local pitch = value.pitch or 1.0
        pitch = pitch % 2.0 * 100

        encoded_notes = encoded_notes .. string.char(self.soundToNote(value.note), volume, pitch)
    end
    return encoded_notes
end

--- Decode notes, volume and pitch into a `table`
---@param encoded_notes string
---@return { note: JukeboxAPI.Sound.note_set.valid_notes, volume: number, pitch: number }[] decoded_notes
function jukeboxAPI:decodeNoteSet(encoded_notes)
    --- @type { note: JukeboxAPI.Sound.note_set.valid_notes, volume: number, pitch: number }[]
    local notes = {}
    local len = #encoded_notes

    for i = 1, len, 3 do
        notes[#notes + 1] = {
            note = self.noteToSound(encoded_notes:byte(i)),
            volume = encoded_notes:byte(i + 1) / 10,
            pitch = encoded_notes:byte(i + 2) / 100,
        }
    end

    return notes
end

---Update and sync `JukeboxAPI.timer.last_position` variable
---@param x any
---@param y any
---@param z any
function pings.updateJukeboxPosition(x, y, z)
    jukeboxAPI.timer.last_position = vec(x, y, z)
end

---Play a set of notes
---@param encoded_notes string
---@param x? number
---@param y? number
---@param z? number
function pings.PlayJukeboxNoteSet(encoded_notes, x, y, z)
    local notes = jukeboxAPI:decodeNoteSet(encoded_notes)

    for _, value in ipairs(notes) do
        if x and y and z then
            sounds:playSound(value.note, vec(x, y, z), value.volume, value.pitch)
        else
            sounds:playSound(value.note, jukeboxAPI.timer.last_position, value.volume, value.pitch)
        end
    end
end

--- Get a list of Sounds registered
---@return JukeboxAPI.Sound.any[]
---@nodiscard
function jukeboxAPI:getSounds()
    return self.sounds
end

--- Untoggle all Actions related to this API
---@param exception? integer If specified, this action index will not be untoggled
function jukeboxAPI:untoggleActions(exception)
    local page = self.config.target_page
    local action_count = #page:getActions()
    exception = exception or 0

    if action_count < 2 then
        return
    end

    for i = 2, action_count do
        if i ~= exception then
            local action = page:getAction(i)
            if action:isToggled() then
                action:toggled(false)
            end
        end
    end
end

--- Set Target Action Wheel Page to fill with Registered Sounds
---@param page Page
---@return JukeboxAPI.Config self
function jukeboxAPI.config:setTargetPage(page)
    if not page or type(page) ~= 'Page' then
        jukeboxAPI.log(
            'error', 'setTargetPage()',
            '"%s" is not a valid page"!',
            page or 'nil'
        )
    else
        self.target_page = page
    end

    return self
end

--- Set the main color used for coloring the Action Wheel Actions
---@param color? Vector3|string
---@return JukeboxAPI.Config self
function jukeboxAPI.config:setActionColor(color)
    color = color or avatar:getColor() --[[@as Vector3|string]]
    local color_type = type(color)

    if color_type ~= "Vector3" and color_type ~= 'string' then
        jukeboxAPI.log(
            'error', 'setActionColor()',
            '"%s" is not a valid color!',
            color or 'nil'
        )
    else
        jukeboxAPI.colors:setColors((color_type == 'string' and vectors.hexToRGB(color) or color)--[[@as Vector3]])
    end
    
    return self
end

--- Should every second Action in the Target Action Wheel Page use Zebra Striping
---@param boolean? boolean
---@return JukeboxAPI.Config self
function jukeboxAPI.config:setActionZebraStripping(boolean)
    self.apply_zebra_stripping_to_actions = boolean and true or false

    return self
end

--- Should add an action to go back to a category
---@param boolean? boolean
---@param page? Page
---@param title? string
---@return JukeboxAPI.Config self
function jukeboxAPI.config:setBackAction(boolean, page, title)
    self.back_action = boolean and true or false
    
    if page and type(page) ~= 'Page' then
        jukeboxAPI.log(
            'error', 'setBackAction()',
            '"%s" is not a valid page"!',
            page or 'nil'
        )
    else
        self.back_action_page = page
    end
    
    if title and type(title) ~= 'string' then
        jukeboxAPI.log(
            'error', 'setBackAction()',
            '"%s" is not a valid name"!',
            title or 'nil'
        )
    else
        self.back_action_name = title
    end

    return self
end

--- Get an offset on the set target page from where Sound Actions start instead of meta buttons
---@return integer offset
---@nodiscard
function jukeboxAPI:getActionOffset()
    return self.config.back_action and 2 or 1
end

--- Takes a Minecraft Item (Music Disc) ID and converts it into a sound
---@param id Minecraft.itemID
---@return Minecraft.soundID
---@nodiscard
function jukeboxAPI.discToSound(id)
    ---@diagnostic disable-next-line: redundant-return-value
    return string.gsub(id, "(music_disc)_(.-)", function(disc, rest)
        return disc .. "." .. rest
    end, 1)
end

--- Compares `sound_id` and `item_id` with all registered Sounds and returns the name and index of an already registered Sound
---@param sound_id Minecraft.soundID
---@param item_id Minecraft.itemID
---@return JukeboxAPI.Sound.normal? duplicate
---@return integer? index
---@nodiscard
function jukeboxAPI:hasBeenRegistered(sound_id, item_id)
    for index, value in ipairs(self.sounds) do
        if value.sound_id and value.sound_id == sound_id and value.item_id == item_id then
            return value --[[@as JukeboxAPI.Sound.normal]], index
        end
    end
end

--- Add a new `JukeboxAPI.Sound` directly to `sounds`
--- Alternative of `jukeboxAPI.registerSound()`
--- NOTE: Use only when you sure you know what you're doing
---@param item_id Minecraft.itemID Item that is represented
---@param sound_id Minecraft.soundID Sound that is played
---@param name string Name of the Sound
---@param author? string Author of the Sound
---@param silent? boolean If `true` does not warn if a Sound was skipped when registering it
---@param ignore_duplicates? boolean If `true` does check for registered duplicates
---@return JukeboxAPI.Sound.normal? sound `JukeboxAPI.Sound` table if a new Sound was registered and `nil` if something was skipped
---@return integer? index An index at which the new Sound was stored at
function jukeboxAPI:insertSound(item_id, sound_id, name, author, silent, ignore_duplicates)
    if not sounds:isPresent(sound_id) then
        if not silent then
            jukeboxAPI.log(
                'warning', "insertSound()",
                'Attempted to register a Sound "%s" with an invalid Sound ID "%s"! Skipping...',
                name, sound_id or 'nil'
            )
        end
        return
    end
    local duplicate = not ignore_duplicates and self:hasBeenRegistered(sound_id, item_id)
    if duplicate then
        if not silent then
            jukeboxAPI.log(
                'warning', "insertSound()",
                'Attempted to register a Sound "%s" ("%s"), but is a duplicate of "%s" ("%s")! Skipping...',
                name, sound_id, duplicate.name, duplicate.sound_id
            )
        end
        return
    end

    --- @type JukeboxAPI.Sound.normal
    local tbl = {
        sound_id = sound_id,
        item_id = item_id,
        name = author and string.format("%s - %s", author, name) or name
    }
    table.insert(self.sounds, tbl)
    return tbl, #self.sounds
end

--- Add a new `JukeboxAPI.Sound.noteblock` directly to `sounds`
--- Alternative of `jukeboxAPI.registerNoteSet()`
--- NOTE: Use only when you sure you know what you're doing
---@param item_id Minecraft.itemID Item that is represented
---@param note_data JukeboxAPI.Sound.note_set.note[] Note that is played
---@param name string Name of the Note Set
---@param author? string Author of the Note Set
---@param silent? boolean If `true` does not warn if a Note Set was skipped when registering it
---@return JukeboxAPI.Sound.note_set.note[]? sound `JukeboxAPI.Sound.note_set` table if a new Note Set was registered and `nil` if something was skipped
---@return integer? index An index at which the new Note Set was stored at
function jukeboxAPI:insertNoteSet(item_id, note_data, name, author, silent)
    for _, set in ipairs(note_data) do
        for _, value in pairs(set) do
            if not sounds:isPresent(value.note) then
                if not silent then
                    jukeboxAPI.log(
                        'warning', "insertNoteSet()",
                        'Attempted to register a Note Set "%s" with an invalid Sound ID "%s"! Skipping...',
                        name, value.note or 'nil'
                    )
                end
                return
            end
        end
    end

    --- @type JukeboxAPI.Sound.note_set
    local tbl = {
        notes = note_data,
        item_id = item_id,
        name = author and string.format("%s - %s", author, name) or name
    }
    table.insert(self.sounds, tbl)
    return tbl, #self.sounds
end

--- Register a new `JukeboxAPI.Sound.normal`
---@param item_id Minecraft.itemID Item that is represented
---@param sound_id? Minecraft.soundID Sound that is played; If `nil` attempts to convert a sound id from the `item_id` field
---@param name? string Name of the Sound
---@param author? string Author of the Sound
---@param silent? boolean If `true` does not warn if a Sound was skipped when registering it; Defaults to `false`
---@param create_action? boolean If `true` creates an Action Wheel Action with this sound to play/stop it; Defaults to `true`
---@return JukeboxAPI.Sound.normal? sound `JukeboxAPI.Sound.normal` table if a new Sound was registered and `nil` if something was skipped
---@return integer? index An index at which the new Sound was stored at
function jukeboxAPI:registerSound(item_id, sound_id, name, author, silent, create_action)
    name = name or 'Unnamed'
    create_action = create_action or true

    if not item_id or type(item_id) ~= 'string' then
        if not silent then
            jukeboxAPI.log(
                'warning', "registerSound()",
                'Attempted to register a Sound "%s" with an invalid Item ID "%s"! Skipping...',
                name, item_id or 'nil'
            )
        end
        return
    end

    if not sound_id or type(sound_id) ~= 'string' then
        sound_id = self.discToSound(item_id)
        if not sounds:isPresent(sound_id) then
            if not silent then
                jukeboxAPI.log(
                    'warning', "registerSound()",
                    'Attempted to register a Sound "%s" that has a non-standard Sound ID "%s"! Skipping...',
                    name, sound_id or 'nil'
                )
            end
            return
        end
    end

    local music, index = self:insertSound(item_id, sound_id, name, author, silent)
    if not music then
        return
    end
    if create_action then
        self:createAction(music, index)
    end
    return music, index
end

--- Register a new `JukeboxAPI.Sound.normal` from the Avatar
---@param item_id Minecraft.itemID Item that is represented
---@param sound_path string A path to a Sound File in the Avatar
---@param name? string Name of the Sound
---@param author? string Author of the Sound
---@param silent? boolean If `true` does not warn if a Sound was skipped when registering it; Defaults to `false`
---@param create_action? boolean If `true` creates an Action Wheel Action with this sound to play/stop it; Defaults to `true`
---@return JukeboxAPI.Sound.normal? sound `JukeboxAPI.Sound.normal` table if a new Sound was registered and `nil` if something was skipped
---@return integer? index An index at which the new Sound was stored at
function jukeboxAPI:registerAvatarSound(item_id, sound_path, name, author, silent, create_action)
    name = name or 'Unnamed'
    create_action = create_action or true

    if not item_id or type(item_id) ~= 'string' then
        if not silent then
            jukeboxAPI.log(
                'warning', "registerAvatarSound()",
                'Attempted to register a Avatar Sound "%s" with an invalid Item ID "%s"! Skipping...',
                name, item_id or 'nil'
            )
        end
        return
    end

    if not sound_path or type(sound_path) ~= 'string' then
        if not silent then
            jukeboxAPI.log(
                'warning', "registerAvatarSound()",
                'Attempted to register an Avatar Sound "%s" with an invalid Sound Path "%s"! Skipping...',
                name, sound_path or 'nil'
            )
        end
        return
    end

    if not sounds:isPresent(sound_path) then
        if not silent then
            jukeboxAPI.log(
                'warning', "registerAvatarSound()",
                'Attempted to register an Avatar Sound "%s" with a Sound Path "%s", but that Sound Path does not contain a Sound File! Skipping...',
                name, sound_path or 'nil'
            )
        end
        return
    end

    local music, index = self:insertSound(item_id, sound_path, name, author, silent)
    if not music then
        return
    end
    if create_action then
        self:createAction(music, index)
    end
    return music, index
end

--- Register a new `JukeboxAPI.Sound.jukebox` from the Avatar
---@param item_id Minecraft.itemID Item that is represented
---@param note_data JukeboxAPI.Sound.note_set.note[] A table containing information about the Note Set
---@param name? string Name of the Note Set
---@param author? string Author of the Note Set
---@param silent? boolean If `true` does not warn if a Note Set was skipped when registering it; Defaults to `false`
---@param create_action? boolean If `true` creates an Action Wheel Action with this note set to play/stop it; Defaults to `true`
---@return JukeboxAPI.Sound.note_set.note[]? sound `JukeboxAPI.Sound.note_set` table if a new Note Set was registered and `nil` if something was skipped
---@return integer? index An index at which the new Note Set was stored at
function jukeboxAPI:registerNoteSet(item_id, note_data, name, author, silent, create_action)
    name = name or 'Unnamed'
    create_action = create_action or true

    if not item_id or type(item_id) ~= 'string' then
        if not silent then
            jukeboxAPI.log(
                'warning', "registerNoteSet()",
                'Attempted to register a Note Set "%s" with an invalid Item ID "%s"! Skipping...',
                name, item_id or 'nil'
            )
        end
        return
    end

    if not note_data or type(note_data) ~= 'table' or #note_data <= 0 then
        if not silent then
            jukeboxAPI.log(
                'warning', "registerNoteSet()",
                'Attempted to register an Note Set "%s" with an invalid Note Set Table "%s"! Skipping...',
                name, note_data or 'nil'
            )
        end
        return
    end

    local music, index = self:insertNoteSet(item_id, note_data, name, author, silent)
    if not music then
        return
    end
    if create_action then
        self:createAction(music, index)
    end
    return music, index
end

--- Register multiple new `JukeboxAPI.Sound.normal`
---@param tbl {item_id: Minecraft.itemID, sound_id: Minecraft.soundID?, name: string?, author: string?}[]
---@param silent? boolean If `true` does not warn if a Sound was skipped when registering it; Defaults to `false`
---@param create_action? boolean If `true` creates an Action Wheel Action with this sound to play/stop it; Defaults to `true`
function jukeboxAPI:registerSounds(tbl, silent, create_action)
    for _, args in ipairs(tbl) do
        self:registerSound(args.item_id, args.sound_id, args.name, args.author, silent, create_action)
    end
end

--- Register multiple new `JukeboxAPI.Sound.normal` from the Avatar
---@param tbl {item_id: Minecraft.itemID, sound_path: Minecraft.soundID, name: string?, author: string?}[]
---@param silent? boolean If `true` does not warn if a Sound was skipped when registering it; Defaults to `false`
---@param create_action? boolean If `true` creates an Action Wheel Action with this sound to play/stop it; Defaults to `true`
function jukeboxAPI:registerAvatarSounds(tbl, silent, create_action)
    for _, args in ipairs(tbl) do
        self:registerSound(args.item_id, args.sound_path, args.name, args.author, silent, create_action)
    end
end

--- Register multiple new `JukeboxAPI.Sound.note_set`
---@param tbl {item_id: Minecraft.itemID, note_data: JukeboxAPI.Sound.note_set.note[], name: string?, author: string?}[]
---@param silent? boolean If `true` does not warn if a Note Set was skipped when registering it; Defaults to `false`
---@param create_action? boolean If `true` creates an Action Wheel Action with this note set to play/stop it; Defaults to `true`
function jukeboxAPI:registerNoteSets(tbl, silent, create_action)
    for _, args in ipairs(tbl) do
        self:registerNoteSet(args.item_id, args.note_data, args.name, args.author, silent, create_action)
    end
end

--- Create and add a new action with a `JukeboxAPI.Sound` instance in a specified `index`;
--- Gives an error if target page has yet to be set via `jukeboxAPI.config:setTargetPage()`
---@param instance JukeboxAPI.Sound.any
---@param index? integer
---@return Action?
function jukeboxAPI:createAction(instance, index)
    if not instance then
        return
    end

    local api_events = self.events
    local cfg = self.config
    local action_colors = self.colors
    local page = cfg.target_page

    if not page or type(page) ~= 'Page' then
        jukeboxAPI.log(
            'error', 'createAction()',
            'Cannot create a new Action Wheel Action as page has yet to be assigned via "JukeboxAPI.config:setTargetPage()"!'
        )
        return
    end
    
    index = index or #page:getActions()+1

    local action = nil
    if index == 1 then
        local i = 1
        if cfg.back_action then
            action = page:newAction(i)
                :title(cfg.back_action_name or 'Go Back')
                :color(action_colors.back)
                :hoverColor(action_colors.back * 0.75)
                :item("minecraft:barrier")
                :onLeftClick(function()
                    action_wheel:setPage(cfg.back_action_page)
                end)

            i = i + 1
        end

        action = page:newAction(i)
            :title('Stop all Sounds')
            :color(action_colors:applyZebraStripping(i))
            :hoverColor(action_colors:applyZebraStripping(i, action_colors.negative * 0.75))
            :item("minecraft:structure_void")
            :onLeftClick(function()
                if containsEventFlag(api_events.ON_ACTION_STOP_ALL_SOUNDS(action, i), 'skip') then
                    return
                end
                self:untoggleActions()
                pings.PlayJukeboxSound()
            end)
    end
    index = index + self:getActionOffset()

    action = page:newAction(index)
        :title(string.format('Play "%s"', instance.name))
        :toggleTitle(string.format('Stop "%s"', instance.name))
        :color(action_colors:applyZebraStripping(index))
        :hoverColor(action_colors.hover)
        :item(instance.item_id)
        :onToggle(function(state)
            if containsEventFlag(api_events.ON_ACTION_PLAY_OR_STOP_SOUND(action, index, state, instance), 'skip') then
                return
            end
            self.timer:restart()
            pings.updateJukeboxPosition(player:getPos():unpack())

            if state then
                self:untoggleActions(index)
                pings.PlayJukeboxSound()
                if instance.notes then
                    self.timer.current_note_set = instance --[[@as JukeboxAPI.Sound.note_set]]
                else
                    pings.PlayJukeboxSound(instance.sound_id, true)
                end
                host:actionbar(string.format('{"text": "Now Playing: %s"}', instance.name), true)
            else
                pings.PlayJukeboxSound(instance.sound_id)
            end
        end)

    return action
end

--- Register all vanilla Music Discs to `JukeboxAPI.sounds`
function jukeboxAPI:registerVanillaDiscs()
    -- 1.0.0
    self:createAction(self:insertSound('minecraft:music_disc_11',                 'minecraft:music_disc.11',                 '11',                   'C418', true, true)--[[@as JukeboxAPI.Sound.normal]])
    self:createAction(self:insertSound('minecraft:music_disc_13',                 'minecraft:music_disc.13',                 '13',                   'C418', true, true)--[[@as JukeboxAPI.Sound.normal]])
    self:createAction(self:insertSound('minecraft:music_disc_blocks',             'minecraft:music_disc.blocks',             'Blocks',               'C418', true, true)--[[@as JukeboxAPI.Sound.normal]])
    self:createAction(self:insertSound('minecraft:music_disc_cat',                'minecraft:music_disc.cat',                'Cat',                  'C418', true, true)--[[@as JukeboxAPI.Sound.normal]])
    self:createAction(self:insertSound('minecraft:music_disc_chirp',              'minecraft:music_disc.chirp',              'Chirp',                'C418', true, true)--[[@as JukeboxAPI.Sound.normal]])
    self:createAction(self:insertSound('minecraft:music_disc_far',                'minecraft:music_disc.far',                'Far',                  'C418', true, true)--[[@as JukeboxAPI.Sound.normal]])
    self:createAction(self:insertSound('minecraft:music_disc_mall',               'minecraft:music_disc.mall',               'Mall',                 'C418', true, true)--[[@as JukeboxAPI.Sound.normal]])
    self:createAction(self:insertSound('minecraft:music_disc_mellohi',            'minecraft:music_disc.mellohi',            'Mellohi',              'C418', true, true)--[[@as JukeboxAPI.Sound.normal]])
    self:createAction(self:insertSound('minecraft:music_disc_stal',               'minecraft:music_disc.stal',               'Stal',                 'C418', true, true)--[[@as JukeboxAPI.Sound.normal]])
    self:createAction(self:insertSound('minecraft:music_disc_strad',              'minecraft:music_disc.strad',              'Strad',                'C418', true, true)--[[@as JukeboxAPI.Sound.normal]])
    self:createAction(self:insertSound('minecraft:music_disc_ward',               'minecraft:music_disc.ward',               'Ward',                 'C418', true, true)--[[@as JukeboxAPI.Sound.normal]])
    -- 1.4.4
    self:createAction(self:insertSound('minecraft:music_disc_wait',               'minecraft:music_disc.wait',               'Wait',                 'C418', true, true)--[[@as JukeboxAPI.Sound.normal]])
    -- 1.16.0
    self:createAction(self:insertSound('minecraft:music_disc_pigstep',            'minecraft:music_disc.pigstep',            'Pigstep',              'Lena Raine', true, true)--[[@as JukeboxAPI.Sound.normal]])
    -- 1.18.0
    self:createAction(self:insertSound('minecraft:music_disc_otherside',          'minecraft:music_disc.otherside',          'Otherside',            'Lena Raine', true, true)--[[@as JukeboxAPI.Sound.normal]])
    -- 1.19.0
    self:createAction(self:insertSound('minecraft:music_disc_5',                  'minecraft:music_disc.5',                  '5',                    'Samuel Åberg', true, true)--[[@as JukeboxAPI.Sound.normal]])
    -- 1.20.0
    self:createAction(self:insertSound('minecraft:music_disc_relic',              'minecraft:music_disc.relic',              'Relic',                'Aaron Cherof', true, true)--[[@as JukeboxAPI.Sound.normal]])
    -- 1.21.0
    self:createAction(self:insertSound('minecraft:music_disc_precipice',          'minecraft:music_disc.precipice',          'Precipice',            'Aaron Cherof', true, true)--[[@as JukeboxAPI.Sound.normal]])
    self:createAction(self:insertSound('minecraft:music_disc_creator_music_box',  'minecraft:music_disc.creator_music_box',  'Creator (Music Box)',  'Lena Raine', true, true)--[[@as JukeboxAPI.Sound.normal]])
    self:createAction(self:insertSound('minecraft:music_disc_creator',            'minecraft:music_disc.creator',            'Creator',              'Lena Raine', true, true)--[[@as JukeboxAPI.Sound.normal]])
end

jukeboxAPI.config:setActionColor()

local timer = jukeboxAPI.timer
events.TICK:register(function ()
    if not host:isHost() then
        return
    end

    if containsEventFlag(jukeboxAPI.events.ON_TIMER_CHANGE(timer, false), 'skip') then
        return
    end

    timer.count = timer.count + 1
    
    if not timer.current_note_set then
        return
    end

    local note_set = timer.current_note_set.notes
    if not note_set then
        return
    end

    local notes = note_set[timer.count]
    if not notes then
        return
    end
    
    pings.PlayJukeboxNoteSet(jukeboxAPI:encodeNoteSet(notes))
end, 'JUKEBOXAPI')

return jukeboxAPI
