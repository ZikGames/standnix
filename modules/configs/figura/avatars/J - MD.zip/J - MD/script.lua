-- Auto generated script file --

--hide vanilla model
vanilla_model.PLAYER:setVisible(false)

vanilla_model.ARMOR:setVisible(false)

local squapi = require("SquAPI")

local anims = require("JimmyAnims")
anims(animations.J)

squapi.doBlink = false
squapi.doBounce = true

local SwingingPhysics = require("swinging_physics")
local swingOnHead = SwingingPhysics.swingOnHead
local swingOnBody = SwingingPhysics.swingOnBody

--Dividing Line


squapi.bewb(
	models.J.root.Body.Tail.TailPivot, --element
	false, --(true)doidle
	-1.0, --(2)bendability
	0.010, --(.025)stiff
	0.100  --(.06)bounce
)

--Dividing Line

squapi.eye(
	models.J.root.Head.Eyes.LEye, --element
	0.25, --(.25)leftdistance
	1.00, --(1.25)rightdistance
	nil, --(.5)updistance
	nil, --(.5)downdistance
	nil  --(false)switchvalues
)

squapi.eye(
	models.J.root.Head.Eyes.REye, --element
	1.00, --(.25)leftdistance
	0.25, --(1.25)rightdistance
	nil, --(.5)updistance
	nil, --(.5)downdistance
	nil  --(false)switchvalues
)
