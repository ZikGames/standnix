# overflow traceback
Simple figura script that tries to add traceback back to stack overflow
i suggest to only use it for debugging when your avatar have stack overflow and you cant find function that causes problem
# how to use:
1. copy your autoScripts from avatar.json to config below or leave autoScripts empty if you dont use autoScripts
2. set autoScripts in avatar.json to: `["traceback"]`
