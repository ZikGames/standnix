local mainPage = action_wheel:newPage()
action_wheel:setPage(mainPage)
models.tardis9_10.Skull:setVisible(false)
models.tardis11.Skull:setVisible(false)
models.tardis12.Skull:setVisible(false)
models.tardis13.Skull:setVisible(false)

function pings.toggled9(state) --ping for 9th-10th
	models.tardis9_10.Skull:setVisible(state)
end
function pings.toggled11(state) --ping for 11th
	models.tardis11.Skull:setVisible(state)
end
function pings.toggled12(state) --ping for 12th
	models.tardis12.Skull:setVisible(state)
end
function pings.toggled13(state) --ping for 13th
	models.tardis13.Skull:setVisible(state)
end

local toggle9 = mainPage:newAction() -- toggle 9th-10th tardis
	:title("9th-10th TARDIS (Disabled)")
    :toggleTitle("9th-10th TARDIS (Enabled)")
    :item("white_wool")
    :toggleItem("blue_wool")
    :setOnToggle(pings.toggled9)
local toggle11 = mainPage:newAction() -- toggle 11th tardis
	:title("11th TARDIS (Disabled)")
    :toggleTitle("11th TARDIS (Enabled)")
    :item("white_wool")
    :toggleItem("blue_wool")
    :setOnToggle(pings.toggled11)
local toggle12 = mainPage:newAction() -- toggle 12th tardis
	:title("12th TARDIS (Disabled)")
    :toggleTitle("12th TARDIS (Enabled)")
    :item("white_wool")
    :toggleItem("blue_wool")
    :setOnToggle(pings.toggled12)
local toggle13 = mainPage:newAction() -- toggle 13th tardis
	:title("13th TARDIS (Disabled)")
    :toggleTitle("13th TARDIS (Enabled)")
    :item("white_wool")
    :toggleItem("blue_wool")
    :setOnToggle(pings.toggled13)
	
	