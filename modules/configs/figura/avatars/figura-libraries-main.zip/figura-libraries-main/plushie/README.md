a simple script that allows to make plushies bigger and snap them to floor
config is in plushie.lua file
