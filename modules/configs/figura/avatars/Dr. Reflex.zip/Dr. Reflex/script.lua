-- Auto generated script file --

vanilla_model.PLAYER:setVisible(false)

vanilla_model.CAPE:setVisible(false)

nameplate.ALL:setText("Dr. Reflex")

function events.tick()
    local attacking = player:isSwingingArm()

    animations.model.attack:setPlaying(attacking)
end

function events.item_render(item)
    if item.id == "minecraft:iron_sword" then
        return models.model.ItemSword
    end
end

function events.item_render(item)
    if item.id == "minecraft:wooden_sword" then
        return models.model.ItemSword
    end
end

function events.item_render(item)
    if item.id == "minecraft:stone_sword" then
        return models.model.ItemSword
    end
end

function events.item_render(item)
    if item.id == "minecraft:golden_sword" then
        return models.model.ItemSword
    end
end

function events.item_render(item)
    if item.id == "minecraft:diamond_sword" then
        return models.model.ItemSword
    end
end

function events.item_render(item)
    if item.id == "minecraft:netherite_sword" then
        return models.model.ItemSword
    end
end

function pings.attack()
    punch = true
    targetEntity = target
    sounds:playSound("BANG", player:getPos(), 1, 1, false)
end

function pings.calm()
    punch = false
end

local attack = keybinds:newKeybind("Attack",keybinds:getVanillaKey("key.attack"))
attack.press = pings.attack
attack.release = pings.calm