-- Auto generated script file --
local squapi = require("SquAPI")

animations.model.windup:play()
--hide vanilla model
vanilla_model.PLAYER:setVisible(false)

--hide vanilla armor model
vanilla_model.ARMOR:setVisible(false)

--hide vanilla cape model
vanilla_model.CAPE:setVisible(false)

--hide vanilla elytra model
vanilla_model.ELYTRA:setVisible(false)

vanilla_model.HELMET_ITEM:setVisible(true)

squapi.bounceWalk:new(
    models.model.root,    --model
    1    --(1) bounceMultiplier
)



nameplate.All:setText('[{"color":"#d67b5b","text":"Coppette"}]')

--replace each nil with the value/parmater you want to use, or leave as nil to use default values :)
--parenthesis are default values for reference
squapi.smoothHead:new(
    {
        models.model.root.Head --element(you can have multiple elements in a table)
    },
		0.5,    --(1) strength(you can make this a table too)
    nil,    --(0.1) tilt
    nil,    --(1) speed
    nil,    --(true) keepOriginalHeadPos
    nil     --(true) fixPortrait
) 