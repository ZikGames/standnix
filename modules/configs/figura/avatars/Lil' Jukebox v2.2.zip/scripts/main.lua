-- Load the API

local JukeboxAPI = require "scripts.JukeboxAPI"

-- Create pages

local home_page = action_wheel:newPage('home')
local sounds_page = action_wheel:newPage('sounds')

-- Setup configuration of the API

JukeboxAPI.config
    :setTargetPage(sounds_page)
    :setActionZebraStripping(true)
    :setBackAction(true, home_page, 'Home')

-- Register vanilla music discs into the API

JukeboxAPI:registerVanillaDiscs()

-- Register additional sounds as discs if you so wish to

-- Single example:
-- JukeboxAPI:registerSound('minecraft:music_disc_otherside', "minecraft:music.overworld.jungle", 'Jungle Theme')
-- Multiple example:
-- JukeboxAPI:registerSounds({
--     {
--         item_id = 'minecraft:music_disc_otherside',
--         sound_id = "minecraft:music.overworld.forest",
--         name = 'Forest Theme',
--         author = 'Mojang'
--     },
--     {
--         item_id = 'minecraft:music_disc_pigstep',
--         sound_id = "minecraft:music.nether.crimson_forest",
--         name = 'Crimson Forest Theme'
--     },
-- })
-- Avatar Sound example:
-- JukeboxAPI:registerAvatarSound('minecraft:diamond_sword', 'path_to_sound', 'Custom Sound', 'Myself')

-- Set the Home Page of the Action Wheel

action_wheel:setPage(home_page)

-- Create a button to move to the Sounds page

home_page:newAction(1)
    :title('Sounds')
    :item('minecraft:jukebox')
    :color(JukeboxAPI.colors:applyZebraStripping(1))
    :hoverColor(JukeboxAPI.colors.hover)
    :onLeftClick(function ()
        action_wheel:setPage(sounds_page)
    end)

-- Initialize variables for the Lil' Jukebox

local last_disk = nil
local last_pos = vec(0, 0, 0)
local is_visible = false
local is_playing = false
local in_jukebox = false
local jukebox = models.lil_jukebox.World
local jukebox_root = jukebox.root
local jukebox_animations = animations['lil_jukebox']
local disk_model = jukebox_root.disk.cube
local disk_item = disk_model:newItem('music_disk')
local anim_insert_disk = jukebox_animations['insert_disk']

--- Toggle on or off visibility of Lil' Jukebox, move it to player's position and save last music id
---@param state boolean
---@param music integer?
---@param x number?
---@param y number?
---@param z number?
function pings.JukeboxState(state, music, x, y, z)
    is_playing = false
    jukebox:setVisible(state)
    if state then
        local sounds = JukeboxAPI.sounds[music] or JukeboxAPI.timer.current_note_set
        last_disk = sounds
        last_pos = vec(x, y, z)

        anim_insert_disk:restart()

        in_jukebox = world.getBlocks(x, y-1 ,z, x, y-1 ,z)[1]:getID() == 'minecraft:jukebox'
        if in_jukebox then
            y = y - 0.55
            anim_insert_disk:setTime(anim_insert_disk:getLength())
        end
        
        -- Referenced from `putting a thing on the ground and having it stay there` by `herodings`
        jukebox:setPos(x*16, y*16, z*16)

        disk_item:setItem(sounds and sounds.item_id or 'minecraft:structure_void')
        disk_item:setVisible(not in_jukebox)
    else
        anim_insert_disk:stop()
    end
end

-- Set defaults for variables/functions/model

jukebox:setVisible(false)
jukebox_root.top:setPrimaryTexture('RESOURCE', 'minecraft:textures/block/jukebox_top.png')
jukebox_root.side:setPrimaryTexture('RESOURCE', 'minecraft:textures/block/jukebox_side.png')
disk_item:setScale(0.25)
disk_item:setRot(0, 90, 0)

-- Replace what happens when a sound is played

JukeboxAPI.events.ON_ACTION_PLAY_OR_STOP_SOUND:register(function (action, index, state, sound)
    -- Only run if a sound is played
    if not state then
        return
    end

    local block, pos, side = nil, nil, nil
    local pos_offsets = {
        ["east"] = { offset = -1.0, dimension = 1 },
        ["south"] = { offset = -1.0, dimension = 3 },
        ["down"] = { offset = 1.0, dimension = 2 }
    }

    if is_visible then
        pos = last_pos --[[@as Vector3]]
    else
        block, pos, side = host:getPickBlock()
        if not block:hasCollision() then
            pos = player:getPos():applyFunc(function (v, i)
                return i ~= 2 and math.floor(v)+0.5 or v
            end)
        else
            pos = pos:applyFunc(function (v, i)
                local side_offset = pos_offsets[side]
                local offset, dimension = nil, nil
                if side_offset then
                    offset, dimension = side_offset.offset, side_offset.dimension
                    offset = i == dimension and offset or 0
                else
                    offset = 0
                end
                
                if i == 1 then
                    return math.floor(v) + 0.5 + offset
                end
                if i == 2 then
                    local floor = math.floor(v)
                    return v == floor and floor + offset or floor + 1.0 + offset
                end
                return math.floor(v) + 0.5 + offset
            end)
        end
    end

    -- Below we want to cancel what the API was going to do here and implement our own logic
    -- It is important to note that you need to do the stuff you skipped yourself too!

    JukeboxAPI:untoggleActions(index)
    pings.PlayJukeboxSound()
    local x, y, z = pos:unpack()
    pings.updateJukeboxPosition(x, y, z)
    if sound.notes then
        JukeboxAPI.timer.current_note_set = sound --[[@as JukeboxAPI.Sound.note_set]]
        pings.JukeboxState(true, nil, x, y, z)
    else
        pings.JukeboxState(true, index - JukeboxAPI:getActionOffset(), x, y, z)
    end

    -- This return means that whatever the API was supposed to do when a sound is played is skipped instead!
    return { skip = true }
end)

-- Make sure the timer is reset when a sound is played/stopped
-- This part was canceled in the previous event

JukeboxAPI.events.ON_ACTION_PLAY_OR_STOP_SOUND:register(function (action, index, state, sound)
    JukeboxAPI.timer:restart()
end)

-- Add additional functionality when a sound is stopped

JukeboxAPI.events.ON_ACTION_PLAY_OR_STOP_SOUND:register(function (action, index, state, sound)
    -- Only run if the sound is stopped
    if state then
        return
    end

    pings.JukeboxState(false, index - JukeboxAPI:getActionOffset())
end)

-- Add additional functionality when all sounds are stopped

JukeboxAPI.events.ON_ACTION_STOP_ALL_SOUNDS:register(function (action, index)
    pings.JukeboxState(false)
end)

-- Replace what happens what the timer increments/resets

JukeboxAPI.events.ON_TIMER_CHANGE:register(function (timer, reset)
    if reset then
        return
    end

    -- If item insert animation is still playing, do not increment timer
    if anim_insert_disk:getTime() < anim_insert_disk:getLength() then
        return { skip = true }
    end
end)

-- Lil' Jukebox's tick function

events.TICK:register(function ()
    is_visible = jukebox:getVisible()

    if is_visible then
        if not is_playing and last_disk and anim_insert_disk:getTime() >= anim_insert_disk:getLength() then
            is_playing = true
            pings.PlayJukeboxSound(last_disk.sound_id, true, last_pos:unpack())
            if host:isHost() then
                host:actionbar(string.format('{"text": "Now Playing: %s"}', last_disk.name), true)
            end
        end

        if anim_insert_disk:getTime() >= anim_insert_disk:getLength() and world.getTime() % 20 == 5 then
            local rand = math.random
            particles:newParticle( 
                'minecraft:note',
                jukebox_root:partToWorldMatrix():apply(0, 8, 0)
            ):scale(in_jukebox and 1.0 or 0.5):color(rand(), rand(), rand())
        end
    end

    if not player:isAlive() then
        local page = JukeboxAPI.config.target_page
        if page then
            page:getAction(JukeboxAPI:getActionOffset()):leftClick()
        end
    end
end, 'JUKEBOX')

-- Lil' Jukebox's render function

events.RENDER:register(function ()
    if is_visible then
        local time = client:getSystemTime()/17.5
        jukebox_root:setPos(0, math.sin(time/26)+1, 0)
        jukebox_root:setRot(0, time % 360, 0)
    end
end, 'JUKEBOX')